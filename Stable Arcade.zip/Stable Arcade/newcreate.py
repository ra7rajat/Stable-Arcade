import os

# Define directories
image_dir = r"G:\New Downloads\ezgif-1-cf26eb8f12-png-278x384-sprite-png\Charrr\images"
output_dir = r"G:\New Downloads\ezgif-1-cf26eb8f12-png-278x384-sprite-png\Charrr\output"

# Ensure output directory exists
os.makedirs(output_dir, exist_ok=True)

# Define character properties
character_name = "Charrr"

# Generate .SFF file
def create_sff_file(image_dir, output_dir, character_name):
    sff_content = "SFF File Content\n"
    for file in sorted(os.listdir(image_dir)):
        if file.endswith(".png"):
            sff_content += f"Add sprite: {file}\n"
            # Placeholder logic for adding sprite to .SFF format

    sff_file_path = os.path.join(output_dir, f"{character_name}.sff")
    with open(sff_file_path, 'w') as sff_file:
        sff_file.write(sff_content)
    print(f".SFF file created at {sff_file_path}")

# Generate .AIR file
def create_air_file(output_dir, character_name):
    air_content = "AIR File Content\n"
    air_content += "[Begin Action 0] ; Idle Animation\n"
    air_content += "0,0, 0,0, 30\n"  # Single frame for idle animation

    air_content += "[Begin Action 200] ; Kick Animation\n"
    air_content += "200,1, 0,0, 10\n"  # Kick frame 1
    air_content += "200,2, 0,0, 10\n"  # Kick frame 2

    air_file_path = os.path.join(output_dir, f"{character_name}.air")
    with open(air_file_path, 'w') as air_file:
        air_file.write(air_content)
    print(f".AIR file created at {air_file_path}")

# Generate .CNS file
def create_cns_file(output_dir, character_name):
    cns_content = f"""
[Data]
life = 1000
attack = 100
defence = 100

[StateDef 200]
type = S
movetype = A
physics = S
anim = 200
ctrl = 0

[State 200, 1]
type = ChangeAnim
trigger1 = AnimTime = 0
value = 200
"""

    cns_file_path = os.path.join(output_dir, f"{character_name}.cns")
    with open(cns_file_path, 'w') as cns_file:
        cns_file.write(cns_content)
    print(f".CNS file created at {cns_file_path}")

# Generate .CMD file
def create_cmd_file(output_dir, character_name):
    cmd_content = f"""
[Command]
name = "kick"
command = x

[State -1, Kick]
type = ChangeState
value = 200
triggerall = command = "kick"
trigger1 = statetype = S
trigger1 = ctrl
"""

    cmd_file_path = os.path.join(output_dir, f"{character_name}.cmd")
    with open(cmd_file_path, 'w') as cmd_file:
        cmd_file.write(cmd_content)
    print(f".CMD file created at {cmd_file_path}")

# Generate .DEF file
def create_def_file(output_dir, character_name):
    def_content = f"""
[Info]
name = "{character_name}"
displayname = "{character_name}"
versiondate = 07,21,2024
mugenversion = 1.0
author = "YourName"
pal.defaults = 1

[Files]
cmd = {character_name}.cmd
cns = {character_name}.cns
st = {character_name}.cns
sprite = {character_name}.sff
anim = {character_name}.air
sound = {character_name}.snd  ; Optional, remove if you don't have a sound file
pal1 = palette1.act  ; Optional
pal2 = palette2.act  ; Optional

[Arcade]
intro.storyboard =
ending.storyboard =
"""

    def_file_path = os.path.join(output_dir, f"{character_name}.def")
    with open(def_file_path, 'w') as def_file:
        def_file.write(def_content)
    print(f".DEF file created at {def_file_path}")

# Create all files
create_sff_file(image_dir, output_dir, character_name)
create_air_file(output_dir, character_name)
create_cns_file(output_dir, character_name)
create_cmd_file(output_dir, character_name)
create_def_file(output_dir, character_name)
