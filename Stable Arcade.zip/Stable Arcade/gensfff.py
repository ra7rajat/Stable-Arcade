from PIL import Image
import struct

def create_sff_file(images, sff_file_name):
    with open(sff_file_name, 'wb') as sff_file:
        # Write a placeholder header (SFF files start with 'SFF ')
        sff_file.write(b'SFF ')

        # Start with the header (length placeholder)
        sff_file.write(struct.pack('<I', 0))

        # Add sprites
        for sprite_name, image_path in images.items():
            img = Image.open(image_path).convert('RGBA')
            width, height = img.size
            img_data = img.tobytes()

            # Write sprite information
            sff_file.write(struct.pack('<I', len(img_data)))  # Sprite data length
            sff_file.write(img_data)  # Sprite data

            # Dummy data (you may need to adjust based on actual SFF specs)
            sff_file.write(struct.pack('<I', width))
            sff_file.write(struct.pack('<I', height))
            sff_file.write(sprite_name.encode('ascii').ljust(16, b'\x00'))

        # Write the final length of the file
        sff_file.seek(4)
        sff_file.write(struct.pack('<I', sff_file.tell()))

    print(f"SFF file '{sff_file_name}' created successfully!")

# Define the image files and their corresponding names
image_files = {
    "stand1": "stand1.png",
    "kick1": "kick1.png",
    "kick2": "kick2.png"
}

# Create the SFF file
create_sff_file(image_files, "Charrr.sff")
