# -*- coding: utf-8 -*-
"""
Created on Wed Jul 24 18:22:42 2024

@author: ASUS
"""

from codecs import encode

def act_to_list(act_file):
        with open(act_file, 'rb') as act:
            raw_data = act.read()                           # Read binary data
        hex_data = encode(raw_data, 'hex')                  # Convert it to hexadecimal values
        total_colors_count = (int(hex_data[-7:-4], 16))     # Get last 3 digits to get number of colors total
        misterious_count = (int(hex_data[-4:-3], 16))       # I have no idea what does it do
        colors_count = (int(hex_data[-3:], 16))             # Get last 3 digits to get number of nontransparent colors

        # Decode colors from hex to string and split it by 6 (because colors are #1c1c1c)               
        palette = [hex_data[i:i+6].decode() for i in range(0, total_colors_count*6, 6)]

        # Add # to each item and filter empty items if there is a corrupted total_colors_count bit        
        palette = ['#'+i for i in palette if len(i)]

        return palette


from PIL import Image
import os

def apply_palette(image_path, palette):
    """Apply a palette to an image and save it."""
    with Image.open(image_path) as img:
        img = img.convert('RGBA')  # Convert to RGBA first
        img = img.convert('P')  # Convert to indexed color
        img.putpalette(palette)  # Apply the new palette
        img.save(image_path)  # Save the processed image

def process_sprites(sprite_dir, palette):
    """Process all images in a directory to use the specified palette."""
    for filename in os.listdir(sprite_dir):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
            image_path = os.path.join(sprite_dir, filename)
            apply_palette(image_path, palette)

def main():
    act_path = 'R:\\mugen-1_1b1\\mugen-1.1b1\\work\\player.act'  # Path to your .act file
    sprite_dir = 'R:\\mugen-1_1b1\\mugen-1.1b1\\work\\player'   # Directory containing your sprite images

    # Load the palette from the .act file
    palette = act_to_list(act_path)

    # Process all sprites in the directory
    process_sprites(sprite_dir, palette)

if __name__ == '__main__':
    main()





##################################



