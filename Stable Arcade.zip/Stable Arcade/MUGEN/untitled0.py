# -*- coding: utf-8 -*-
"""
Created on Wed Jul 24 17:20:22 2024

@author: ASUS
"""

import os
import subprocess
from PIL import Image

# Paths (customize these paths according to your setup)
mugen_dir = 'R:\\mugen-1_1b1\\mugen-1.1b1'
chars_dir = os.path.join(mugen_dir, 'chars')
work_dir = os.path.join(mugen_dir, 'work')
kfm_dir = os.path.join(chars_dir, 'kfm')
player_dir = os.path.join(chars_dir, 'player')

# Make the player directory
os.makedirs(player_dir, exist_ok=True)

# Copy KFM files to Player directory and rename them
file_mappings = {
    'kfm.air': 'player.air',
    'kfm.cns': 'player.cns',
    'kfm.cmd': 'player.cmd',
    'kfm.def': 'player.def',
    'kfm.ai': 'player.ai'
}

for src_file, dest_file in file_mappings.items():
    src_path = os.path.join(kfm_dir, src_file)
    dest_path = os.path.join(player_dir, dest_file)
    if os.path.exists(src_path):
        with open(src_path, 'r') as f_src:
            content = f_src.read()
        with open(dest_path, 'w') as f_dest:
            f_dest.write(content.replace('kfm', 'player'))

# Prepare the palette (requires manual work in Photoshop, saved as player.act)
palette_path = os.path.join(work_dir, 'player.act')

# Load and apply palette to all sprites
sprite_dir = os.path.join(work_dir, 'player')
output_sprite_dir = os.path.join(player_dir, 'sprites')
os.makedirs(output_sprite_dir, exist_ok=True)

def apply_palette(image_path, palette_path):
    with Image.open(image_path) as img:
        img = img.convert('RGB')
        img = img.quantize(palette=Image.open(palette_path))
        return img

for sprite_name in os.listdir(sprite_dir):
    sprite_path = os.path.join(sprite_dir, sprite_name)
    if sprite_path.endswith('.png'):
        output_sprite_path = os.path.join(output_sprite_dir, sprite_name)
        sprite = apply_palette(sprite_path, palette_path)
        sprite.save(output_sprite_path)

# Create player-sff.def file
sff_def_path = os.path.join(work_dir, 'player-sff.def')
with open(sff_def_path, 'w') as f:
    f.write(f"""
[Output]
filename = {player_dir}/player.sff

[Option]
sprite.compress.5 = lz5
sprite.compress.8 = rle8
sprite.compress.24 = none
sprite.decompressonload = 0
sprite.detectduplicates = 0
sprite.autocrop = 1
pal.detectduplicates = 1
pal.discardduplicates = 1
pal.reverseact = 0
pal.reversepng = 0

[Pal]
1,1, stand00.png

[Option]
sprite.usepal = 1,1

[Sprite]
0, 0, stand00.png,  18,105
0, 1, stand01.png,  18,104
0, 2, stand02.png,  18,104
0, 3, stand03.png,  18,104
; end of file
""")

# Create player.sff using sprmake2
subprocess.run([os.path.join(mugen_dir, 'sprmake2'), sff_def_path])

# Create player.air file
air_path = os.path.join(player_dir, 'player.air')
with open(air_path, 'w') as f:
    f.write("""
[Begin Action 0]   ;Action 0 is the standing animation
Clsn2Default: 2
Clsn2[0] = -10,  0, 10,-79
Clsn2[1] =  -4,-92,  6,-79
0,3, 0,0, 7  
0,2, 0,0, 7
0,1, 0,0, 7
0,0, 0,0, 7
0,1, 0,0, 7
0,2, 0,0, 7
;end of file
""")

# Run M.U.G.E.N to test the character
subprocess.run([os.path.join(mugen_dir, 'mugen'), 'player', 'player'])
