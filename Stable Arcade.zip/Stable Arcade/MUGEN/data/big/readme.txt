M.U.G.E.N Large-capacity select screen
--------------------------------------

M.U.G.E.N       (c) 2011 Elecbyte
                www.elecbyte.com


For MUGEN version 1.0.

This motif gives you up to 60 slots for characters.

To use this motif, type:

  mugen -r big

To set this as your default motif, set the following line in mugen.cfg:

  motif = data/big/system.def

If desired, you can make a separate character roster for this motif.
To do so, copy select.def from the data/ directory into data/big/.
